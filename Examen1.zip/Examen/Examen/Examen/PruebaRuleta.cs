﻿using Examen;
Ruleta ruleta = new Ruleta();
ruleta.showMenuPrincipal();
