using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Examen3.Data;
using Examen3.Models;

namespace Examen3.Controllers
{
    public class BebidasController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _hostEnvironment;

        public BebidasController(ApplicationDbContext context, IWebHostEnvironment hostEnvironment)
        {
            _context = context;
            _hostEnvironment = hostEnvironment;

        }

        // GET: Bebidas
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.Bebidas.Include(b => b.Estilo);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: Bebidas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Bebidas == null)
            {
                return NotFound();
            }

            var bebidas = await _context.Bebidas
                .Include(b => b.Estilo)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bebidas == null)
            {
                return NotFound();
            }

            return View(bebidas);
        }

        // GET: Bebidas/Create
        public IActionResult Create()
        {
            ViewData["IdEstilo"] = new SelectList(_context.Estilos, "Id", "Nombre");
            return View();
        }

        // POST: Bebidas/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Nombre,IdEstilo,Alcohol,Precio,UrlImagen")] Bebidas bebidas)
        {
            if (ModelState.IsValid)
            {
                string rutaPrincipal = _hostEnvironment.WebRootPath;
                var archivos = HttpContext.Request.Form.Files;
                if (archivos.Count() > 0){
                    string nombreArchivo = Guid.NewGuid().ToString(); 
                    var subidas = Path.Combine(rutaPrincipal, @"imagenes\bebidas\");
                    var extension = Path.GetExtension(archivos[0].FileName);
                    using (var fileStream = new FileStream(Path.Combine(subidas, nombreArchivo + extension), FileMode.Create)){

                        archivos[0].CopyTo(fileStream);
                    }
                    bebidas.UrlImagen = @"imagenes\bebidas\" + nombreArchivo + extension;
                }
            
                _context.Add(bebidas);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEstilo"] = new SelectList(_context.Estilos, "Id", "Nombre", bebidas.IdEstilo);
            return View(bebidas);
        }

        // GET: Bebidas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Bebidas == null)
            {
                return NotFound();
            }

            var bebidas = await _context.Bebidas.FindAsync(id);
            if (bebidas == null)
            {
                return NotFound();
            }
            ViewData["IdEstilo"] = new SelectList(_context.Estilos, "Id", "Nombre", bebidas.IdEstilo);
            return View(bebidas);
        }

        // POST: Bebidas/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Nombre,IdEstilo,Alcohol,Precio,UrlImagen")] Bebidas bebidas)
        {
            if (id != bebidas.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    string rutaPrincipal = _hostEnvironment.WebRootPath;
                    var archivos = HttpContext.Request.Form.Files;
                    if (archivos.Count() > 0){
                        Bebidas? bebidasBD =await _context.Bebidas.FindAsync(id);
                        if (bebidasBD != null && bebidasBD.UrlImagen!= null){
                            var rutaImagenActual = Path.Combine(rutaPrincipal, bebidasBD.UrlImagen);
                            if (System.IO.File.Exists(rutaImagenActual)){
                                System.IO.File.Delete(rutaImagenActual);
                            }
                            _context.Entry(bebidasBD).State = EntityState.Detached;
                        }
                        string nombreArchivo = Guid.NewGuid().ToString(); 
                        var subidas = Path.Combine(rutaPrincipal, @"imagenes\bebidas\");
                        var extension = Path.GetExtension(archivos[0].FileName);
                        using (var fileStream = new FileStream(Path.Combine(subidas, nombreArchivo + extension), FileMode.Create)){

                            archivos[0].CopyTo(fileStream);
                        }
                        bebidas.UrlImagen = @"imagenes\bebidas\" + nombreArchivo + extension;
                        _context.Entry(bebidas).State = EntityState.Modified;
                    }
                    _context.Update(bebidas);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BebidasExists(bebidas.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEstilo"] = new SelectList(_context.Estilos, "Id", "Nombre", bebidas.IdEstilo);
            return View(bebidas);
        }

        // GET: Bebidas/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Bebidas == null)
            {
                return NotFound();
            }

            var bebidas = await _context.Bebidas
                .Include(b => b.Estilo)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bebidas == null)
            {
                return NotFound();
            }

            return View(bebidas);
        }

        // POST: Bebidas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Bebidas == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Bebidas'  is null.");
            }
            var bebidas = await _context.Bebidas.FindAsync(id);
            if (bebidas != null)
            {
                _context.Bebidas.Remove(bebidas);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BebidasExists(int id)
        {
          return (_context.Bebidas?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
