using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Examen3.Data;
using Examen3.Models;

namespace Examen3.Controllers
{
    public class ComidasController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ComidasController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Comidas
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.Comidas.Include(c => c.Estilo);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: Comidas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Comidas == null)
            {
                return NotFound();
            }

            var comidas = await _context.Comidas
                .Include(c => c.Estilo)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (comidas == null)
            {
                return NotFound();
            }

            return View(comidas);
        }

        // GET: Comidas/Create
        public IActionResult Create()
        {
            ViewData["IdEstilo"] = new SelectList(_context.Estilos, "Id", "Nombre");
            return View();
        }

        // POST: Comidas/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Nombre,IdEstilo,Promocion,Precio")] Comidas comidas)
        {
            //if (ModelState.IsValid)
            //{
                _context.Add(comidas);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            //}
            ViewData["IdEstilo"] = new SelectList(_context.Estilos, "Id", "Nombre", comidas.IdEstilo);
            return View(comidas);
        }

        // GET: Comidas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Comidas == null)
            {
                return NotFound();
            }

            var comidas = await _context.Comidas.FindAsync(id);
            if (comidas == null)
            {
                return NotFound();
            }
            ViewData["IdEstilo"] = new SelectList(_context.Estilos, "Id", "Nombre", comidas.IdEstilo);
            return View(comidas);
        }

        // POST: Comidas/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Nombre,IdEstilo,Promocion,Precio")] Comidas comidas)
        {
            if (id != comidas.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(comidas);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ComidasExists(comidas.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEstilo"] = new SelectList(_context.Estilos, "Id", "Nombre", comidas.IdEstilo);
            return View(comidas);
        }

        // GET: Comidas/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Comidas == null)
            {
                return NotFound();
            }

            var comidas = await _context.Comidas
                .Include(c => c.Estilo)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (comidas == null)
            {
                return NotFound();
            }

            return View(comidas);
        }

        // POST: Comidas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Comidas == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Comidas'  is null.");
            }
            var comidas = await _context.Comidas.FindAsync(id);
            if (comidas != null)
            {
                _context.Comidas.Remove(comidas);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ComidasExists(int id)
        {
          return (_context.Comidas?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
