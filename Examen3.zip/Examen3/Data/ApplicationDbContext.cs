﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Examen3.Models;

namespace Examen3.Data;

public class ApplicationDbContext : IdentityDbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }
    public DbSet<Estilo> Estilos { get; set; }
    public DbSet<Bebidas> Bebidas { get; set; }
    public DbSet<Comidas> Comidas { get; set; }
    public DbSet<Entradas> Entradas { get; set; }

    
}
