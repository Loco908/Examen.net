using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Examen3.Models
{
    public class Bebidas
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [Display(Name = "Nombre bebidas")]
        public string Nombre { get; set; }
        [Display(Name = "Seccion")]
        public int IdEstilo { get; set; }
        [ForeignKey("IdEstilo")]
        public Estilo? Estilo { get; set; }
        [Required]
        [Display(Name = "% de Alcohol")]
        public double Alcohol { get; set; }
        public double? Precio { get; set; }
        [Display(Name = "Imagen de la bebida")]
        public String? UrlImagen { get; set; }

    }
}