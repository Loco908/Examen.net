using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Examen3.Models
{
    public class Entradas
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [Display(Name = "Nombre de Entradas")]
        public string Nombre { get; set; }
        [Display(Name = "Seccion")]
        public int IdEstilo { get; set; }
        [ForeignKey("IdEstilo")]
        public Estilo Estilo { get; set; }
        [Required]
        [Display(Name = "Agrega una promoción")]
        public double Promocion { get; set; }
        public double Precio { get; set; }
    }
}